<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Models\About;
use App\Http\Controllers\Controller;
use View;
use Redirect;
use Session;

class AboutsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware(['admin','auth']);
    }
    
    public function index()
    {
        $abouts = About::all();
        $view = View::make('abouts.index');
        $view->abouts = $abouts;
        return $view;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function updateAbout(Request $request, $id)
    {
        $about = About::find($id);
        $about->icon_class=$request->input('icon_class');
        $about->title = $request->input('title');
        $about->content = $request->input('content');
        $about->save();
        $request->session()->flash('success','Elément mis à jour avec succés ! ');
        return Redirect::to(route('abouts.index'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
