@extends('layouts.app')
@section('content')
{{Auth::logout()}}
<div class="background-img" style="background-image: url('https://www.tourmag.com/photo/art/grande/20125146-23731412.jpg?v=1518445820');">
        <div class="filter"></div>
        <div class="container">
            <div class="row">
                <h2 class="title"> &nbsp;Merci pour votre inscription <br/>
                </h2>
            </div>
            <div class="container-cards space-top">
                <div class="row">
                    <h5 class="discover-pages text-center">Votre demande d'adhéreson a etait prise en consideration, nous allons la traiter le plutot possible</h5>
                </div>
            </div>
        </div>
    </div>
@endsection