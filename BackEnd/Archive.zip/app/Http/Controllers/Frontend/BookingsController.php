<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Booking;
use View;
use Redirect;

class BookingsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware(['admin','auth']);
    }

    public function index()
    {
        $view = View::make('bookings.index');
        $bookings = Booking::all();
        $view->bookings = $bookings;
        return $view;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $booking = Booking::find($id);
        $view = View::make('bookings.show');
        $view->booking = $booking;
        return $view;
    }

    public function vourcher($id)
    {
        $booking = Booking::find($id);
        $view = View::make('bookings.vourcher');
        $view->booking = $booking;
        return $view;
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function validateBooking(Request $request ,$id){
        $booking = Booking::find($id);
        $booking->status = 1;
        $booking->save();
        $request->session()->flash('success','Commande validée avec succés ! ');
        return Redirect::to(route('bookings.index'));
    }
    public function cancelBooking(Request $request, $id){
        $booking = Booking::find($id);
        $booking->status = 2 ;
        $booking->save();
        $request->session()->flash('success','Commande annulée avec succés ! ');
        return Redirect::to(route('bookings.index'));
    }
}
